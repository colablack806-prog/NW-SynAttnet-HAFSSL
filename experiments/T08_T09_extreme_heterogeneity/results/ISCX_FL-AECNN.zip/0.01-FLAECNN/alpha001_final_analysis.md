# α = 0.01 (Table VIII) – Final Analysis and Text

ISCX-VPN2016, K = 10 clients, Dirichlet α = 0.01, FedAvg, 100 rounds, 3 seeds (0, 1, 2).
Both models use the **same** client partition, the **same** labeled flows (200 per class per client;
2,010 / 1,654 / 1,798 labeled flows for seeds 0 / 1 / 2) and the **same** test set (8,244 flows).
Verified from the output files: identical split, test flows, client partitions and labels for each seed.

## 1. Main result (test set, mean ± std over 3 seeds, %, macro-averaged)

| Model | Accuracy | Macro-P | Macro-R | Macro-F1 | Worst-class recall |
|---|---|---|---|---|---|
| **HAFSSL** | **63.48 ± 5.17** | **66.41 ± 6.51** | **59.75 ± 6.33** | **53.73 ± 9.82** | 9.82 ± 14.00 |
| FL-AECNN | 38.06 ± 5.95 | 25.39 ± 18.79 | 36.84 ± 9.68 | 26.03 ± 10.81 | 1.03 ± 1.79 |

Per seed (accuracy / macro-F1):

| Seed | HAFSSL | FL-AECNN | Gain |
|---|---|---|---|
| 0 | 64.18 / 46.52 | 40.76 / 22.42 | +23.42 / +24.10 |
| 1 | 57.99 / 49.76 | 31.23 / 17.49 | +26.76 / +32.26 |
| 2 | 68.27 / 64.92 | 42.19 / 38.19 | +26.08 / +26.72 |

## 2. Statistical tests (paired design)

| Test | Result |
|---|---|
| Paired t-test, accuracy | gain +25.42 pp, 95% CI [+21.04, +29.80], p = 0.0016 (Holm 0.0032) |
| Paired t-test, macro-F1 | gain +27.70 pp, 95% CI [+17.34, +38.05], p = 0.0075 (Holm 0.0075) |
| McNemar, seed 0 | HAFSSL right / FL-AECNN wrong: 2,018 flows; opposite: 87; p < 10⁻³⁰⁰ |
| McNemar, seed 1 | 2,332 vs 126; p < 10⁻³⁰⁰ |
| McNemar, seed 2 | 3,394 vs 1,244; p = 1.5 × 10⁻²¹⁸ |

Decision rule (pre-registered): "better" only if the Holm-corrected paired t-test **and** McNemar on every seed are significant → **both satisfied**.

## 3. Per-class recall (%, mean ± std over seeds)

| Class | HAFSSL | FL-AECNN |
|---|---|---|
| Chat | 59.3 ± 40.5 | 5.3 ± 9.1 |
| Email | 91.1 ± 6.4 | 50.2 ± 41.6 |
| File | 58.4 ± 50.4 | 30.9 ± 53.6 |
| Streaming | 80.1 ± 24.5 | 75.6 ± 21.2 |
| VoIP | **9.8 ± 14.0** | 22.2 ± 38.5 |

- Classes with recall < 50% per seed: HAFSSL 2 / 2 / 1; FL-AECNN 3 / 3 / 2.
- Classes with recall < 5% per seed: HAFSSL 2 / 1 / 0; FL-AECNN 3 / 3 / 1.
- **HAFSSL failure mode:** VoIP is mostly predicted as Email (74.6% of true VoIP flows); Email acts as an attractor class (40.4% of all predictions).
- **FL-AECNN failure mode:** predictions collapse onto Email (35.9%) and Streaming (38.4%); Chat is almost never recognized (5.3%), and 42.6% of File flows are predicted as Streaming.
- FL-AECNN is better than HAFSSL only on VoIP (22.2 vs 9.8%), driven by one seed (66.7%); in the other two seeds both models have VoIP ≈ 0–4%.

## 4. Stability and convergence (validation accuracy, last 10 rounds)

| Seed | HAFSSL | FL-AECNN |
|---|---|---|
| 0 | 64.2 ± 5.5 (56.9–73.2) | 41.6 ± 0.4 (40.6–41.9) |
| 1 | 59.3 ± 7.8 (46.3–72.8) | 31.0 ± 2.9 (23.7–34.6) |
| 2 | 62.8 ± 11.2 (42.3–72.7) | 37.2 ± 8.5 (16.5–44.6) |

Neither model reaches 90% validation accuracy in 100 rounds. HAFSSL oscillates strongly between rounds (up to ±11 points), but its last-10-round average stays 20–28 points above FL-AECNN in every seed, so the gain is not an artefact of the final round.

## 5. Cost

| Model | Params sent | Comm./round (9 active clients, up + down) | Total (100 rounds) | Training time per run (Tesla T4) |
|---|---|---|---|---|
| HAFSSL | 461,013 | 33.2 MB | 3,319 MB | 2.55 h |
| FL-AECNN | 384,589 | 27.7 MB | 2,769 MB | 1.15 h |

HAFSSL costs about **20% more communication** and **2.2× more local computation**.

---

## 6. Text for the paper

### Table VIII, extreme-heterogeneity part (replace the old rows and delete the "6× more labels" footnote)

| Model | Aggregation | K | α | Labels | Rounds | Acc (%) | F1 (%) | Worst-class recall (%) | Total comm. |
|---|---|---|---|---|---|---|---|---|---|
| HAFSSL | FedAvg | 10 | 0.01 | 200/class/client | 100 | **63.5 ± 5.2**\* | **53.7 ± 9.8**\* | 9.8 ± 14.0† | 3,319 MB |
| FL-AECNN [10] | FedAvg | 10 | 0.01 | 200/class/client | 100 | 38.1 ± 6.0 | 26.0 ± 10.8 | 1.0 ± 1.8† | 2,769 MB |

Footnote: Mean ± std over three seeds; both models use identical client partitions, labeled flows and local training. \* Significant vs FL-AECNN (paired t-test with Holm correction and McNemar's test on every seed, p < 0.01). † At least one class below 50% recall in every seed; per-class results in Table [X] / Appendix C.

LaTeX rows:
```
HAFSSL (Proposed) & FedAvg & 10 & 0.01 & 200/class/client & 100 & \textbf{63.5 $\pm$ 5.2}$^{*}$ & \textbf{53.7 $\pm$ 9.8}$^{*}$ & 9.8 $\pm$ 14.0$^{\dagger}$ & 3,319 MB \\
FL-AECNN [10]     & FedAvg & 10 & 0.01 & 200/class/client & 100 & 38.1 $\pm$ 6.0 & 26.0 $\pm$ 10.8 & 1.0 $\pm$ 1.8$^{\dagger}$ & 2,769 MB \\
```

### Section V-E (extreme heterogeneity paragraph)

> Under extreme heterogeneity (α = 0.01), most clients hold flows of a single service class (Appendix C). Both models are trained with identical client partitions, labeled flows (200 per class per client) and local training (autoencoder pre-training, supervised encoder fine-tuning and classifier training, 3 local epochs, 100 rounds). HAFSSL reaches 63.5 ± 5.2% accuracy and 53.7 ± 9.8% macro-F1, compared with 38.1 ± 6.0% and 26.0 ± 10.8% for FL-AECNN. The gain is consistent across seeds (+23.4 to +26.8 points) and statistically significant (paired t-test with Holm correction, p ≤ 0.008; McNemar's test p < 10⁻²⁰⁰ on every seed). Nevertheless, extreme heterogeneity degrades both models: neither reaches 90% accuracy within 100 rounds, the global accuracy of HAFSSL oscillates between rounds, and in every seed at least one class falls below 50% recall. The dominant failure of HAFSSL is VoIP, which is mostly predicted as Email (9.8% recall), whereas FL-AECNN collapses most predictions onto Email and Streaming and almost never recognizes Chat (5.3% recall). HAFSSL therefore degrades considerably less than the baseline, but this regime remains an open problem; gradient-correction or personalized federated methods are a natural next step. The improvement comes at about 20% more communication and 2.2× more local computation per round.

### Appendix C (replace the old α = 0.01 paragraph)

> Table [X] reports per-class recall at α = 0.01 (mean ± std over three seeds). HAFSSL recognizes Email (91.1%), Streaming (80.1%), Chat (59.3%) and File (58.4%), but VoIP collapses (9.8%), with 74.6% of VoIP flows predicted as Email, which acts as an attractor class. FL-AECNN collapses more severely: 74.3% of its predictions fall on Email and Streaming, Chat recall is 5.3%, and 42.6% of File flows are predicted as Streaming. Per seed, HAFSSL has 2, 2 and 1 classes below 50% recall, against 3, 3 and 2 for FL-AECNN. These patterns show that the attention-based representation preserves more classes under near one-class-per-client partitioning, but does not remove the class-collapse problem of FedAvg at this level of heterogeneity.

### Setting statement (Section V-A or Table I)

> For α = 0.01, HAFSSL uses an additional hybrid attention block in the classifier head and a supervised encoder fine-tuning stage (2 epochs, learning rate 10⁻⁴), with 3 local epochs and 100 rounds to limit client drift; FL-AECNN is trained with the identical procedure and label budget, without attention.

---

## 7. Response letter (Reviewer 1)

**Comment 1 (statistics), α = 0.01 part:**
> The α = 0.01 comparison is now repeated with three seeds (0, 1, 2). For each seed, HAFSSL and FL-AECNN use the same client partition, the same labeled flows and the same frozen test set, so the comparison is paired. HAFSSL obtains 63.5 ± 5.2% accuracy versus 38.1 ± 6.0% for FL-AECNN (gain +25.4 points, 95% CI [+21.0, +29.8]); the difference is significant under a paired t-test with Holm correction (p = 0.003) and under McNemar's test on every seed (p < 10⁻²⁰⁰). Labeled flows are sampled per client (200 per class held by the client) with a fixed seed; no early stopping is used, and the global model after round 100 is evaluated.

**Comment 1/7 (the unfair baseline footnote):**
> We agree that the previous comparison, in which FL-AECNN received six times more labels, was not appropriate. Both models now receive exactly the same labeled flows and the same local training procedure; the only difference is the attention blocks. The footnote has been removed.

**Comment 7 (overstated robustness):**
> We agree, and we have rewritten this result. Under α = 0.01 both models degrade: neither reaches 90% accuracy, HAFSSL's accuracy oscillates between rounds, and at least one class falls below 50% recall in every seed (VoIP for HAFSSL, mostly predicted as Email). We now report per-class recall in the main text and describe the result as a substantially smaller degradation than the baseline, not as strong robustness. The abstract no longer claims "strong robustness to heterogeneous client distributions".

**Comment 4 (cost):**
> At α = 0.01, HAFSSL sends 33.2 MB per round (3,319 MB in total) versus 27.7 MB (2,769 MB) for FL-AECNN, and needs about 2.2× more local computation. We report this trade-off explicitly next to the accuracy gain.

**Note on the change from the previous version:**
> The previous value of 69.14% came from a single run evaluated with an earlier protocol (averaged local models, no duplicate removal); the new value of 63.5 ± 5.2% replaces it.
