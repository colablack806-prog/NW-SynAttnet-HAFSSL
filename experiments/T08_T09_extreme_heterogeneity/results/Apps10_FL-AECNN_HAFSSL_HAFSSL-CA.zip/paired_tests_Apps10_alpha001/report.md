# Paired tests: Apps10, Dirichlet alpha = 0.01, K = 10

McNemar's exact test (accuracy) and a paired randomization test with 10,000 swaps (macro-F1) per seed, on the same frozen test set; 95% CIs from 10,000 paired bootstrap resamples (per seed, not adjusted for multiple testing); Holm-Bonferroni correction within each family; significance at 0.05. Differences are compared model (B) minus baseline (A).

## HAFSSL (standard) vs FL-AECNN (original) (main, FedAvg)

| Seed | Acc A | Acc B | Δ acc [95% CI] | McNemar p (Holm) | F1 A | F1 B | Δ macro-F1 [95% CI] | Randomization p (Holm) |
|---|---|---|---|---|---|---|---|---|
| 0 | 0.4439 | 0.5062 | +0.0623 [+0.0577, +0.0669] | < 0.001 | 0.3324 | 0.4268 | +0.0944 [+0.0896, +0.0991] | < 0.001 |
| 1 | 0.4136 | 0.3266 | -0.0871 [-0.0926, -0.0815] | < 0.001 | 0.3204 | 0.2014 | -0.1190 [-0.1234, -0.1146] | < 0.001 |
| 2 | 0.3444 | 0.4056 | +0.0612 [+0.0563, +0.0661] | < 0.001 | 0.2323 | 0.3070 | +0.0747 [+0.0705, +0.0790] | < 0.001 |

Across seeds: Δ acc +0.0121 ± 0.0859, Δ macro-F1 +0.0167 ± 0.1179; HAFSSL (standard) higher on 2/3 seeds (acc) and 2/3 (macro-F1). Wilcoxon signed-rank p = 1.000 (acc), 1.000 (macro-F1); with 3 seeds the smallest possible p is 0.250.

## HAFSSL (clfatt) vs FL-AECNN (original) (ablation, FedAvg)

| Seed | Acc A | Acc B | Δ acc [95% CI] | McNemar p (Holm) | F1 A | F1 B | Δ macro-F1 [95% CI] | Randomization p (Holm) |
|---|---|---|---|---|---|---|---|---|
| 0 | 0.4439 | 0.6108 | +0.1668 [+0.1597, +0.1744] | < 0.001 | 0.3324 | 0.5305 | +0.1981 [+0.1913, +0.2050] | < 0.001 |
| 1 | 0.4136 | 0.6513 | +0.2377 [+0.2299, +0.2456] | < 0.001 | 0.3204 | 0.6083 | +0.2879 [+0.2811, +0.2949] | < 0.001 |
| 2 | 0.3444 | 0.3939 | +0.0495 [+0.0452, +0.0538] | < 0.001 | 0.2323 | 0.3106 | +0.0784 [+0.0747, +0.0821] | < 0.001 |

Across seeds: Δ acc +0.1513 ± 0.0950, Δ macro-F1 +0.1881 ± 0.1051; HAFSSL (clfatt) higher on 3/3 seeds (acc) and 3/3 (macro-F1). Wilcoxon signed-rank p = 0.250 (acc), 0.250 (macro-F1); with 3 seeds the smallest possible p is 0.250.

## HAFSSL (clfatt) vs HAFSSL (standard) (ablation, FedAvg)

| Seed | Acc A | Acc B | Δ acc [95% CI] | McNemar p (Holm) | F1 A | F1 B | Δ macro-F1 [95% CI] | Randomization p (Holm) |
|---|---|---|---|---|---|---|---|---|
| 0 | 0.5062 | 0.6108 | +0.1045 [+0.0981, +0.1111] | < 0.001 | 0.4268 | 0.5305 | +0.1037 [+0.0974, +0.1102] | < 0.001 |
| 1 | 0.3266 | 0.6513 | +0.3247 [+0.3174, +0.3321] | < 0.001 | 0.2014 | 0.6083 | +0.4069 [+0.4001, +0.4137] | < 0.001 |
| 2 | 0.4056 | 0.3939 | -0.0117 [-0.0175, -0.0060] | < 0.001 | 0.3070 | 0.3106 | +0.0036 [-0.0023, +0.0094] | 0.242 |

Across seeds: Δ acc +0.1392 ± 0.1708, Δ macro-F1 +0.1714 ± 0.2100; HAFSSL (clfatt) higher on 2/3 seeds (acc) and 3/3 (macro-F1). Wilcoxon signed-rank p = 0.500 (acc), 0.250 (macro-F1); with 3 seeds the smallest possible p is 0.250.
