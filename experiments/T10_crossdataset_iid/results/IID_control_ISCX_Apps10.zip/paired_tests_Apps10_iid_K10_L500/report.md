# Paired tests: Apps10, IID, K = 10, 500 labels per client, 50 rounds

McNemar's exact test (accuracy) and a paired randomization test with 10,000 swaps (macro-F1) per seed, on the same frozen test set; 95% CIs from 10,000 paired bootstrap resamples; Holm-Bonferroni correction within each family; significance at 0.05. Across seeds: paired t-test and Wilcoxon. Differences are compared model (B) minus baseline (A).

## HAFSSL (standard) vs FL-AECNN (original) (main, FedAvg)

| Seed | Acc A | Acc B | Δ acc [95% CI] | McNemar p (Holm) | F1 A | F1 B | Δ macro-F1 [95% CI] | Randomization p (Holm) |
|---|---|---|---|---|---|---|---|---|
| 0 | 0.9261 | 0.9300 | +0.0039 [+0.0018, +0.0061] | 0.002 | 0.9250 | 0.9292 | +0.0042 [+0.0020, +0.0064] | 0.002 |
| 1 | 0.9325 | 0.9295 | -0.0030 [-0.0049, -0.0012] | 0.007 | 0.9314 | 0.9286 | -0.0028 [-0.0047, -0.0010] | 0.010 |
| 2 | 0.9309 | 0.9337 | +0.0028 [+0.0008, +0.0049] | 0.011 | 0.9299 | 0.9328 | +0.0029 [+0.0008, +0.0050] | 0.011 |

Across seeds: Δ acc +0.0013 ± 0.0037 (paired t p = 0.619), Δ macro-F1 +0.0014 ± 0.0037 (paired t p = 0.571); HAFSSL (standard) higher on 2/3 seeds (acc). Wilcoxon p = 0.750 (acc); with 3 seeds the smallest possible p is 0.250.
