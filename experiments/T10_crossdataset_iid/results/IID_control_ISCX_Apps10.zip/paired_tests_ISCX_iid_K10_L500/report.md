# Paired tests: ISCX, IID, K = 10, 500 labels per client, 50 rounds

McNemar's exact test (accuracy) and a paired randomization test with 10,000 swaps (macro-F1) per seed, on the same frozen test set; 95% CIs from 10,000 paired bootstrap resamples; Holm-Bonferroni correction within each family; significance at 0.05. Across seeds: paired t-test and Wilcoxon. Differences are compared model (B) minus baseline (A).

## HAFSSL (standard) vs FL-AECNN (original) (main, FedAvg)

| Seed | Acc A | Acc B | Δ acc [95% CI] | McNemar p (Holm) | F1 A | F1 B | Δ macro-F1 [95% CI] | Randomization p (Holm) |
|---|---|---|---|---|---|---|---|---|
| 0 | 0.9694 | 0.9689 | -0.0005 [-0.0032, +0.0022] | 1.000 | 0.9691 | 0.9684 | -0.0007 [-0.0034, +0.0020] | 1.000 |
| 1 | 0.9706 | 0.9743 | +0.0036 [+0.0013, +0.0059] | 0.019 | 0.9706 | 0.9739 | +0.0033 [+0.0009, +0.0057] | 0.019 |
| 2 | 0.9733 | 0.9699 | -0.0034 [-0.0059, -0.0010] | 0.027 | 0.9729 | 0.9692 | -0.0036 [-0.0062, -0.0011] | 0.019 |

Across seeds: Δ acc -0.0001 ± 0.0035 (paired t p = 0.972), Δ macro-F1 -0.0003 ± 0.0035 (paired t p = 0.885); HAFSSL (standard) higher on 1/3 seeds (acc). Wilcoxon p = 1.000 (acc); with 3 seeds the smallest possible p is 0.250.
